import React from 'react'
import Sidebar from './Components/Sidebar/Sidebar'
import Main from './Components/Main/main'
import { ThemeContext } from './Context/ThemeContext'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NextPage from './Components/Main/Nextpage';
import Loginform from './Components/Main/Login';
import GradientAnimation from './Components/Main/GradientAnimation';
import  Login  from './Components/Main/Login';
import Signupform from './Components/Main/Signupform';
import UploadLlm from './Components/Sidebar/UploadLlm';

const App = () => {
  return (
    <>
       <Sidebar/>
       {/* <GradientAnimation/> */}
        
        <ThemeContext/>
            <Routes>
                <Route path="/" element={<Main />} />
                <Route path='/ThemeContext' element={ <ThemeContext/>}/>
                <Route path="/NextPage" element={<NextPage />} />
                <Route path ='/Login' element={<Login/>}/>
                <Route path='/Signupform' element={<Signupform/>}/>
                <Route path='/uploadllm' element={<UploadLlm />}/>
            </Routes>
    </>
  )
}

export default App
