 import React, { useState } from 'react';

function UploadLlm() {
    const [llmMessage, setLlmMessage] = useState('');
    const [docMessage, setDocMessage] = useState('');
    const [uploadedModels, setUploadedModels] = useState([]);
    const [nameInput, setNameInput] = useState('');
    const [urlInput, setUrlInput] = useState('');
    const [promptInput, setPromptInput] = useState('');

  
    const handleUploadLLM = async () => {
        if (!nameInput || !urlInput || !promptInput) {
            setLlmMessage("Please fill in all fields.");
            return;
        }

        try {
            const response = await fetch('http://20.244.32.29:8080/download_gguf', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: nameInput,
                    url: urlInput,
                    prompt: promptInput,
                }),
            });

            if (response.ok) {
                setLlmMessage("LLM file uploaded successfully!");
                setUploadedModels(prev => [...prev, nameInput]);
                setNameInput('');
                setUrlInput('');
                setPromptInput('');
            } else {
                setLlmMessage("Failed to upload LLM file.");
            }
        } catch (error) {
            console.error("Upload error:", error);
            setLlmMessage("An error occurred while uploading.");
        }
    };

    
    const handleDelete = async (name) => {
        try {
            const response = await fetch('http://20.244.32.29:8080/delete_model', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name }),
            });

            if (response.ok) {
                setUploadedModels(prev => prev.filter(model => model !== name));
            } else {
                alert("Failed to delete model.");
            }
        } catch (error) {
            console.error("Delete error:", error);
        }
    };

   
    const handleUploadDocument = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('http://20.244.32.29:8080/upload_document', {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                setDocMessage("Document uploaded successfully!");
            } else {
                setDocMessage("Failed to upload document.");
            }
        } catch (error) {
            console.error("Document upload error:", error);
            setDocMessage("An error occurred while uploading the document.");
        }
    };

    return (
        <div style={{ padding: '2rem' }}>
           
            <button
                onClick={() => window.history.back()}   
                style={{
                    background: '#ccc',
                    padding: '0.5rem 1rem',
                    marginBottom: '1rem',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                }}
            >
                ← Back
            </button>

         
            <div style={{ display: 'flex', gap: '2rem' }}>
                
                <div style={{ flex: 1, border: '1px solid #ccc', padding: '1.5rem', borderRadius: '8px' }}>
                    <h3>Upload LLM File</h3>

                    <input
                        type="text"
                        placeholder="Model Name"
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        style={{ width: '100%', marginBottom: '0.5rem', padding: '0.5rem' }}
                    />
                    <input
                        type="text"
                        placeholder="Model URL"
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        style={{ width: '100%', marginBottom: '0.5rem', padding: '0.5rem' }}
                    />
                    <textarea
                        placeholder="Prompt"
                        value={promptInput}
                        onChange={(e) => setPromptInput(e.target.value)}
                        rows={4}
                        style={{ width: '100%', marginBottom: '0.5rem', padding: '0.5rem' }}
                    />

                    <button
                        onClick={handleUploadLLM}
                        style={{
                            background: '#1976d2',
                            color: '#fff',
                            border: 'none',
                            padding: '0.5rem 1rem',
                            borderRadius: '4px',
                            cursor: 'pointer'
                        }}
                    >
                        Upload LLM
                    </button>

                    {llmMessage && (
                        <div style={{ marginTop: '1rem', color: llmMessage.includes("successfully") ? "green" : "red" }}>
                            {llmMessage}
                        </div>
                    )}
                </div>

             
                <div style={{ flex: 1, border: '1px solid #ccc', padding: '1.5rem', borderRadius: '8px' }}>
                    <h3>Upload Document (PDF/DOCX)</h3>
                    <label style={{
                        display: 'inline-block',
                        marginTop: '1rem',
                        background: '#1976d2',
                        color: '#fff',
                        padding: '0.5rem 1rem',
                        borderRadius: '4px',
                        cursor: 'pointer'
                    }}>
                        Upload Document
                        <input
                            type="file"
                            accept=".pdf,.doc,.docx"
                            onChange={handleUploadDocument}
                            style={{ display: 'none' }}
                        />
                    </label>
                    {docMessage && (
                        <div style={{ marginTop: '1rem', color: docMessage.includes("successfully") ? "green" : "red" }}>
                            {docMessage}
                        </div>
                    )}
                </div>
            </div>

           
            <div style={{
                marginTop: '2rem',
                border: '1px solid #ccc',
                padding: '1.5rem',
                borderRadius: '8px'
            }}>
                <h3>Uploaded Models</h3>
                {uploadedModels.length === 0 ? (
                    <p>No models uploaded yet.</p>
                ) : (
                    <ul style={{ listStyle: 'none', padding: 0 }}>
                        {uploadedModels.map((model, index) => (
                            <li key={index} style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                marginBottom: '0.5rem'
                            }}>
                                <span>{model}</span>
                                <button
                                    onClick={() => handleDelete(model)}
                                    style={{
                                        background: 'red',
                                        color: '#fff',
                                        border: 'none',
                                        padding: '0.25rem 0.5rem',
                                        borderRadius: '4px',
                                        cursor: 'pointer'
                                    }}
                                >
                                    Delete
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
}

export default UploadLlm;
