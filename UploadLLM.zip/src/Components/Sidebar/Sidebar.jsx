import React, { useState, useContext } from "react";
import "./Sidebar.css";
import { ThemeContext } from "../../Context/ThemeContext";
import { IconButton, Tooltip } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import AddIcon from '@mui/icons-material/Add';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import HelpIcon from '@mui/icons-material/Help';
import HistoryIcon from '@mui/icons-material/History';
import SettingsIcon from '@mui/icons-material/Settings';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import { useNavigate } from "react-router-dom";

function Sidebar() {
    const [extended, setExtended] = useState(false);
    const [showThemeOptions, setShowThemeOptions] = useState(false);
    const { theme, setTheme } = useContext(ThemeContext);
    const navigate = useNavigate();

    return (
        <div className={`sidebar ${theme === "dark" ? "dark" : "light"}`}>
            <div className="top">
                <div style={{ display: 'flex', flexDirection: "column", justifyContent: "flex-start", alignItems: "flex-start" }}>
                    <Tooltip title="Extended Menu" placement="right" arrow>
                        <IconButton>
                            <MenuIcon
                                className="menu"
                                style={{ color: "#b4b4b4" }}
                                onClick={() => setExtended((prev) => !prev)}
                            />
                        </IconButton>
                    </Tooltip>
                </div>

                <div className="new-chat">
                    <Tooltip title="New Chat" arrow>
                        <IconButton>
                            <AddIcon style={{ color: "#b4b4b4" }} />
                        </IconButton>
                    </Tooltip>
                    {extended ? <p>New Chat</p> : null}
                </div>

                {extended ? (
                    <div className="recent">
                        <p className="recent-title">Recent</p>
                        <div className="recent-entry">
                            <ChatBubbleOutlineIcon style={{ fontSize: "20px", color: "#b4b4b4" }} />
                            <p> What is React...</p>
                        </div>
                    </div>
                ) : null}
            </div>

            <div className="bottom">
                <div className="bottom-item recent-entry">
                    <Tooltip title="Help" placement="right" arrow>
                        <HelpIcon style={{ color: "#b4b4b4" }} />
                    </Tooltip>
                    {extended ? <p>Help</p> : null}
                </div>

                <div className="bottom-item recent-entry">
                    <Tooltip title="Activity" placement="right" arrow>
                        <HistoryIcon style={{ color: "#b4b4b4" }} />
                    </Tooltip>
                    {extended ? <p>Activity</p> : null}
                </div>

                <div
                    className="bottom-item recent-entry"
                    onClick={() => setShowThemeOptions((prev) => !prev)}
                >
                    <Tooltip title="Settings" placement="right" arrow>
                        <SettingsIcon style={{ color: "#b4b4b4" }} />
                    </Tooltip>
                    {extended ? <p>Settings</p> : null}
                </div>

                <div
                    className="bottom-item recent-entry"
                    onClick={() => navigate("/uploadllm")}
                >
                    <Tooltip title="Upload File" placement="right" arrow>
                        <UploadFileIcon style={{ color: "#b4b4b4" }} />
                    </Tooltip>
                    {extended ? <p>Upload File</p> : null}
                </div>
            </div>
        </div>
    );
}

export default Sidebar;
