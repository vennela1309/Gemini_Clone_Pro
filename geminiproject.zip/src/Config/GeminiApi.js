const { GoogleGenerativeAI } = require("@google/generative-ai");

const apiKey = "AIzaSyAW6t21HEJh9HSArM-pmMcNDMNJYCWKoJ4";
const genAI = new GoogleGenerativeAI(apiKey);

const model = genAI.getGenerativeModel({
  model: "gemini-pro", // fallback model to avoid region issues
});

const generationConfig = {
  temperature: 1,
  topP: 0.95,
  topK: 40,
  maxOutputTokens: 8192,
  responseMimeType: "text/plain",
};

async function run(prompt) {
  try {
    const chatSession = model.startChat({
      generationConfig,
      history: [],
    });

    const result = await chatSession.sendMessage(prompt);

    // Safely return text
    return result.response.text || "No response received.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error generating response.";
  }
}

export default run;
