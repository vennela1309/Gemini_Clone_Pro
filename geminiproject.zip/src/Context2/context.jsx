import { createContext, useState } from 'react';
import run from '../Config/GeminiApi';

export const Context = createContext();

const ContextProvider = (props) => {
    const [input, SetInput] = useState('');
    const [resentPrompt, setResentPrompt] = useState("");
    const [prevPrompts, setPrevPrompts] = useState([]);
    const [showResult, setShowResult] = useState(false);
    const [loading, setLoading] = useState(false);
    const [resultData, setResultData] = useState('');

    const onSent = async () => {
        if (!input.trim()) return;

        setResultData("");
        setLoading(true);
        setShowResult(true);
        const response = await run(input);
        setResultData(response);
        setLoading(false);
        SetInput('');
    }

    const contextValue = {
        prevPrompts,
        setPrevPrompts,
        onSent,
        setResentPrompt,
        resentPrompt,
        showResult,
        loading,
        resultData,
        input,
        SetInput,
    };

    return (
        <Context.Provider value={contextValue}>
            {props.children}
        </Context.Provider>
    );
}

export default ContextProvider;
