import React, { useState,useContext } from "react";
import './Nextpage.css'
import { assets } from "../../assets/assets";
import { ThemeContext } from "../../Context/ThemeContext";
import KeyboardVoiceIcon from '@mui/icons-material/KeyboardVoice';
import CloseIcon from '@mui/icons-material/Close';
import { IconButton, Tooltip } from "@mui/material";
import { useNavigate } from "react-router-dom";

const NextPage = () => {
    const navigate = useNavigate()
    const { theme } = useContext(ThemeContext);
    const [input,setInputValue] = useState('')
    
    console.log(theme)

    const startspeech = ()=>{
        
        // document.write("start speech")
    }
    const stopspeech = ()=>{
        // document.write("start speech")
    }
    const startSpeechRecognition = () => {
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = "en-US";

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            setInputValue(transcript);
        };

        recognition.start();
    };
    return (
        <div className={`nextpage-container ${theme === "dark" ? "dark" : "light"}`}>
            <div className="animated-video">
                <h1>   Welcome to speech recognition</h1>
                     
                <video 
                    src={assets.video} 
                    // controls 
                    autoPlay 
                    loop 
                    muted 
                    className="speech-video"
                >
                    
                </video>
               
                <div className="mic_open_container">
                <div className = "mic_open"  >
                    <Tooltip title='Open Mic'>
                        <IconButton>
                        <KeyboardVoiceIcon  onClick={startSpeechRecognition}/>
                        </IconButton>
                    </Tooltip>
                   
                </div>
                <div className="mic_close" >
                    <Tooltip title="Close Mic">
                        <IconButton>
                        <CloseIcon onClick={()=>navigate('/')}/>
                        </IconButton>
                    </Tooltip>
                    
                </div>
                </div>
            </div>
        </div>
    );
};

export default NextPage;
