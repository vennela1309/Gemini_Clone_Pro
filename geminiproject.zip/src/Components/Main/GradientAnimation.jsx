import React, { useEffect, useRef } from "react";
import "./GradientAnimation.css";

const GradientAnimation = () => {
    const canvasRef = useRef(null);

    useEffect(() => {
        const canvas = canvasRef.current;

        if (!canvas) return; // Ensure the canvas exists
        const ctx = canvas.getContext("2d");

        let width = (canvas.width = window.innerWidth);
        let height = (canvas.height = window.innerHeight);
        let gradientAngle = 0;
        let animationFrameId;

        const createGradient = () => {
            const gradient = ctx.createLinearGradient(0, 0, width, height);
            gradient.addColorStop(0, "rgba(63, 94, 251, 0.8)");
            gradient.addColorStop(1, "rgba(252, 70, 107, 0.8)");
            return gradient;
        };

        const animate = () => {
            ctx.clearRect(0, 0, width, height);
            gradientAngle += 0.02;

            ctx.fillStyle = createGradient();
            ctx.fillRect(0, 0, width, height);

            animationFrameId = requestAnimationFrame(animate);
        };

        const handleResize = () => {
            width = canvas.width = window.innerWidth;
            height = canvas.height = window.innerHeight;
        };

        window.addEventListener("resize", handleResize);
        animate();

        return () => {
            cancelAnimationFrame(animationFrameId); // Cancel the animation frame
            window.removeEventListener("resize", handleResize); // Clean up the resize listener
        };
    }, []);

    return <canvas ref={canvasRef} className="gradient-canvas"></canvas>;
};

export default GradientAnimation;
