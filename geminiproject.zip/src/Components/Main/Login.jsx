import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import { assets } from "../../assets/assets";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "firebase/auth";
import { initializeApp } from "firebase/app";

const firebaseConfig = {
    apiKey: "AIzaSyCQh9l8zMY7Vo8abatMzrDXN1sEvFVpCtM",
    authDomain: "geminicloneproject.firebaseapp.com",
    projectId: "geminicloneproject",
    storageBucket: "geminicloneproject.appspot.com",
    messagingSenderId: "370812719561",
    appId: "1:370812719561:web:d26c655a4edb2328ce5818",
    measurementId: "G-8CLPD7QK39"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

// Force account selection every time
provider.setCustomParameters({
    prompt: "select_account"
});

const Login = () => {
    const [user, setUser] = useState(null);
    const navigate = useNavigate();

    const signInWithGoogle = async () => {
        try {
            const result = await signInWithPopup(auth, provider);
            const user = result.user;
            localStorage.setItem("username", user.displayName);
            localStorage.setItem("profilePic", user.photoURL);
            navigate("/");
        } catch (error) {
            console.error("Google Sign-In Error:", error);
        }
    };

    const googleSignOut = async () => {
        await signOut(auth);
        localStorage.removeItem("username");
        localStorage.removeItem("profilePic");
        setUser(null);
    };

    useEffect(() => {
        onAuthStateChanged(auth, (user) => {
            if (user) {
                setUser(user);
            } else {
                setUser(null);
            }
        });
    }, []);

    return (
        <div className="login-page">
            <div className="modal-content">
                <h2>{user ? `Welcome, ${user.displayName}` : "Login"}</h2>

                {!user ? (
                    <>
                        <button onClick={signInWithGoogle} className="google-btn">
                            <img src={assets.googlelogoimg} className="googlelogoimg" alt="Google logo" /> Continue with Google
                        </button>
                    </>
                ) : (
                    <>
                        <button onClick={googleSignOut} className="signout-btn">Sign Out</button>
                        <button onClick={() => navigate("/")} className="back-home-btn">Go to Home</button>
                    </>
                )}
            </div>
        </div>
    );
};

export default Login;
