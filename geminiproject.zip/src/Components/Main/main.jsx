import React, { useContext, useState, useEffect, useRef } from "react";
import "./main.css";
import { assets } from "../../assets/assets";
import { ThemeContext } from "../../Context/ThemeContext";
import { Link, useNavigate } from "react-router-dom";
import LogoutIcon from "@mui/icons-material/Logout";
import LightModeIcon from "@mui/icons-material/LightMode";
import DarkModeIcon from "@mui/icons-material/DarkMode";
import { FaEdit, FaCopy, FaThumbsUp, FaThumbsDown, FaPlus, FaImage, FaFileAlt, FaBrain } from "react-icons/fa";
import { motion } from "framer-motion"; // Animation library
import FitbitIcon from '@mui/icons-material/Fitbit';
import Tooltip from '@mui/material/Tooltip';
import { IconButton } from "@mui/material";
import MicIcon from '@mui/icons-material/Mic';
import SendIcon from '@mui/icons-material/Send';
import { Context } from "../../Context2/context";

const Main = () => {
    const { theme, setTheme } = useContext(ThemeContext);
    const [selectedFile, setSelectedFile] = useState(null);
    const [showNextPage, setShowNextPage] = useState(false);
    const [name, setName] = useState("");
    const [profilePic, setProfilePic] = useState(assets.default_avatar);
    const [inputValue, setInputValue] = useState("");
    const [message, setMessage] = useState([]);
    const [editingIndex, setEditingIndex] = useState(null);
    const [isCardOpen, setIsCardOpen] = useState(false);

    const [editText, setEditText] = useState(""); // Stores the text being edited
    const [editPopup, setEditPopup] = useState(false); // Controls popup visibility

    const chatEndRef = useRef(null);

    // FIX: Object Destructuring here
    const { onSent, resentPrompt, showResult, loading, resultData, input, SetInput } = useContext(Context);

    const botResponses = [
        "Hello! How can I assist you?",
        "Interesting question!",
        "I'm not sure, but I can find out.",
        "Can you clarify?",
        "That sounds great!",
        "Let's explore this further!",
    ];

    // Scroll to the latest message
    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [message]);

    const handleInputChange = (e) => {
        setInputValue(e.target.value);
    };

    const handleSendMessage = () => {
        if (!inputValue.trim()) return;

        if (editingIndex !== null) {
            setMessage((prevMessages) => {
                const updatedMessages = [...prevMessages];
                updatedMessages[editingIndex].text = inputValue;
                return updatedMessages;
            });
            setEditingIndex(null);
        } else {
            setMessage((prevMessages) => [
                ...prevMessages,
                { text: inputValue, sender: "user" },
            ]);

            setTimeout(() => {
                const botReply = botResponses[Math.floor(Math.random() * botResponses.length)];
                setMessage((prevMessages) => [...prevMessages, { text: botReply, sender: "bot" }]);
            }, 1000);
        }

        setInputValue("");
    };

    const handleKeyDown = (e) => {
        if (e.key === "Enter") handleSendMessage();
    };

    const handleEditMessage = (index) => {
        setEditingIndex(index);
        setEditText(message[index].text);
        setEditPopup(true);
    };

    const handleCopyMessage = (text) => {
        navigator.clipboard.writeText(text);
    };

    const navigate = useNavigate();

    useEffect(() => {
        const storedName = localStorage.getItem("username");
        const storedProfilePic = localStorage.getItem("profilePic");
        if (storedName) setName(storedName);
        if (storedProfilePic) setProfilePic(storedProfilePic);
    }, []);

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) setSelectedFile(file);
        const formData = new FormData();
        formData.append(file,selectedFile)
        console.log("file data", file);
    };

   

    const handleSaveEdit = () => {
        setMessage((prevMessages) => {
            const updatedMessages = [...prevMessages];
            updatedMessages[editingIndex].text = editText;
            return updatedMessages;
        });
        setEditPopup(false);
        setEditingIndex(null);
    };

    const handleSignOut = () => {
        localStorage.removeItem("username");
        localStorage.removeItem("profilePic");
        setName("");
        setProfilePic(assets.default_avatar);
        navigate("/");
    };

    return (
        <div className={`main ${theme === "dark" ? "dark" : "light"}`}>
            <>
                <div className="nav">
                    <p>HEADING</p>
                    <div className="btnstyle">
                        <button
                            className="theme-toggle-btn"
                            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                        >
                            {theme === "dark" ? <LightModeIcon sx={{ color: "#fff" }} /> : <DarkModeIcon sx={{color:"gray"}}/>}
                        </button>
                        {!name ? (
                            <Link to="/login">
                                <button className="loginbtn">Log-In</button>
                            </Link>
                        ) : (
                            <div className="user-info">  
                                <div onClick={handleSignOut}>
                                    <LogoutIcon  style={{color:"#b4b4b4"}}/>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
                <div className="main-container">
                    <div className="greet">
                        {!inputValue && message.length === 0 && <p><span>Hello, {name || "User"}</span></p>}
                    </div>
                    <div className="chat-container">
                        {message.map((msg, index) => (
                            <motion.div
                                key={index}
                                className={`chat-message ${msg.sender}`}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.3 }}
                            >
                                {msg.sender !== "user" && <FitbitIcon />}
                                <p className="msg-text" >{msg.text}</p>
                                <div className="message-actions">
                                    {msg.sender !== "user" && (
                                        <>
                                            <Tooltip title="Good Response" arrow >
                                                <IconButton>
                                                    <FaThumbsUp className="icon" style={{ color: "#b4b4b4", fontSize: "18px" }} />
                                                </IconButton>
                                            </Tooltip>
                                            <Tooltip title='Bad Response' arrow>
                                                <IconButton>
                                                    <FaThumbsDown className="icon" style={{ color: "#b4b4b4", fontSize: "18px" }} />
                                                </IconButton>
                                            </Tooltip>
                                            <Tooltip title='Copy'arrow>
                                                <IconButton>
                                                    <FaCopy onClick={() => handleCopyMessage(msg.text)} className="icon" style={{ color: "#b4b4b4", fontSize: "18px" }} />
                                                </IconButton>
                                            </Tooltip>
                                        </>
                                    )}
                                    {msg.sender === "user" && (
                                        <Tooltip title='Edit Message' placement="right" arrow>
                                            <IconButton>
                                                <FaEdit
                                                    onClick={() => handleEditMessage(index)}
                                                    className="icon"
                                                    style={{ color: "#b4b4b4", fontSize: "20px" }}
                                                />
                                            </IconButton>
                                        </Tooltip>
                                    )}
                                </div>
                            </motion.div>
                        ))}
                        {editPopup && (
                            <div className="edit-popup">
                                <div className="edit-popup-content">
                                    <input
                                        type="text"
                                        value={editText}
                                        onChange={(e) => setEditText(e.target.value)}
                                        className="edit-input"
                                    />
                                    <div className="edit-popup-buttons">
                                        <button onClick={handleSaveEdit} className="edit-send">Send</button>
                                        <button onClick={() => setEditPopup(false)} className="edit-cancle">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        )}
                        <div ref={chatEndRef} />
                    </div>

                    <div className="main-bottom">
                        <div className="search-box">
                            <Tooltip title='More Options' arrow>
                                <IconButton>
                                    <FaPlus
                                        className="plus-icon"
                                        onClick={() => setIsCardOpen(!isCardOpen)}
                                        style={{ cursor: "pointer", fontSize: "1.5rem", color: "#b4b4b4" }}
                                    />
                                </IconButton>
                            </Tooltip>

                            {isCardOpen && (
                                <div className="options-card show">
                                    <div className="option" onClick={() => document.getElementById("imageInput").click()}>
                                        <FaImage className="icon" style={{ color: "#b4b4b4" }} />
                                        <p className="card-text">Upload Image</p>
                                    </div>
                                    <input id="imageInput" type="file" style={{ display: "none" }} onChange={handleFileChange} />
                                    <div className="option" onClick={() => document.getElementById("fileInput").click()}>
                                        <FaFileAlt className="icon" style={{ color: "#b4b4b4" }} />
                                        <p className="card-text">Upload File</p>
                                    </div>
                                    <input id="fileInput" type="file" style={{ display: "none" }} onChange={handleFileChange} />
                                    <div className="option" onClick={() => document.getElementById("fileInput").click()}>
                                        <FaBrain className="icon" style={{ color: "#b4b4b4" }} />
                                        <p className="card-text">LLM Processing</p>
                                    </div>
                                    <input id="fileInput" type="file" style={{ display: "none" }} onChange={handleFileChange} />
                                </div>
                            )}

                            <input
                                type="text"
                                placeholder="Enter a prompt here"
                                value={inputValue}
                                onChange={handleInputChange}
                                onKeyDown={handleKeyDown}
                            />
                            <Tooltip title='Send' arrow>
                                <IconButton>
                                    <SendIcon onClick={handleSendMessage} style={{color:"#b4b4b4"}}/>
                                </IconButton>
                            </Tooltip>
                            <Link to={'/Nextpage'}>
                                <Tooltip title='Mic' arrow>
                                    <IconButton>
                                        <MicIcon 
                                        style={{color:"#b4b4b4"}}
                                        
                                        />
                                    </IconButton>
                                </Tooltip>
                            </Link>
                        </div>
                    </div>
                </div>
            </>
        </div>
    );
};

export default Main;
